import{_ as e,o as n,c as o}from"./index-7987354c.js";const t={name:"Index01"};function c(r,s,a,_,d,p){return n(),o("div",null," Index22 ")}const l=e(t,[["render",c]]);export{l as default};
