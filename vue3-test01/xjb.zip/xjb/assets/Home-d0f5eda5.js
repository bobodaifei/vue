import{_ as e,o,c as t}from"./index-7987354c.js";const c={name:"Home"};function n(r,s,a,_,m,p){return o(),t("div",null," Home ")}const l=e(c,[["render",n]]);export{l as default};
