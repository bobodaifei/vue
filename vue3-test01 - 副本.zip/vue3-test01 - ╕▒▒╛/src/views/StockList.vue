<script setup>
import request from "@/utils/request";
import { ref, reactive } from "vue";


import { ElMessage } from 'element-plus';


let currentPage = ref(1)
let pageSize = ref(15)
let total = ref(0)
// let tableData = reactive([])
let tableData = ref([])

const load = () => {
  request.get("/javaweb05/stock?method=selectPage", {
    params: {
      currentPage: currentPage.value,
      pageSize: pageSize.value
    }
  }).then((res) => {
    if (res.code == "0") {
      // tableData.length = 0
      // tableData.push(...res.data.records)
      tableData.value = res.data.records
      total.value = res.data.total
      
    }
  });
}

load()

const handleSizeChange = (_pageSize) => {   // 改变当前每页的个数触发
  pageSize.value = _pageSize
  load()
}
const handleCurrentChange = (_currentPage) => {  // 改变当前页码触发
  currentPage.value = _currentPage
  load()
}

let goodList = reactive([])
const load1 = () => {
  request.get("/javaweb05/stock?method=toAdd").then((res) => {
    if (res.code == "0") {
      goodList = res.data
    }
  });
}

load1()


let status = reactive([
  { 'name': '下架', 'value': 0 },
  { 'name': '上架', 'value': 1 }
])

let dialogTableVisible = ref(false)
let form = reactive({})
const handleAdd = () => {
  load1()
  dialogTableVisible.value = true
  form = reactive({})
}

const handleEdit = (_row) => {
  dialogTableVisible.value = true
  form = _row
}

const edit = () => {
  if (form.good_name) {
    request.put("/javaweb05/stock?method=update", form).then((res) => {
      if (res.code == "0") {
        ElMessage({
          message: '修改成功',
          type: 'success',
        })
        load()
      } else {
        ElMessage.error(res.msg)
      }
    });
  } else {
    request.put("/javaweb05/stock?method=add", form).then((res) => {
      if (res.code == "0") {
        ElMessage({
          message: '新增成功',
          type: 'success',
        })
        load()
      } else {
        ElMessage.error(res.msg)
      }
    });
  }
  dialogTableVisible.value = false
  form = reactive({})
}

const handleDelete = (_good_no) => {
  request.delete("/javaweb05/stock?method=delete&good_no=" + _good_no).then((res) => {
    if (res.code == "0") {
      ElMessage({
        message: '新增成功',
        type: 'success',
      })
      load()
    } else {
      ElMessage.error(res.msg)
    }
  });
}
</script>

<template>
  <div>
    <el-button @click="handleAdd()" type="primary">新增</el-button>
    
    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="good_no" label="商品编号" />
      <el-table-column prop="good_name" label="商品名称" />
      <el-table-column prop="price" label="商品价格" />
      <el-table-column prop="is_online" label="商品状态">
        <template #default="scope">
          <el-tag v-if="scope.row.is_online == '1'" class="ml-2" type="success">上架</el-tag>
          <el-tag v-else class="ml-2" type="danger">下架</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="stock" label="商品库存" />
      <el-table-column prop="sal" label="操作">
        <template #default="scope">
          <el-button @click="handleEdit(scope.row)">修改</el-button>
          <el-popconfirm @confirm="handleDelete(scope.row.good_no)" title="确认删除?">
            <template #reference>
              <el-button type="danger">删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination v-model:current-page="currentPage" :page-size="pageSize" :page-sizes="[5, 15, 20, 25]"
      layout="total, sizes, prev, pager, next, jumper" :total="total" @size-change="handleSizeChange"
      @current-change="handleCurrentChange" />


    <el-dialog v-model="dialogTableVisible" width="470px" title="修改">
      <el-form :model="form" label-width="120px" style="max-width: 360px">
        <el-form-item label="商品名称">
          <el-input v-if="form.good_name" v-model="form.good_name" disabled />
          <el-select v-else v-model="form.good_no" class="m-2" placeholder="选择商品">
            <el-option v-for="item in goodList" :key="item.good_no" :label="item.good_name" :value="item.good_no" />
          </el-select>
        </el-form-item>
        <el-form-item label="商品库存">
          <el-input v-model="form.stock" />
        </el-form-item>
        <el-form-item label="商品状态">
          <el-select v-model="form.is_online" class="m-2" placeholder="选择状态">
            <el-option v-for="item in status" :key="item.value" :label="item.name" :value="item.value" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogTableVisible = false">返回</el-button>
          <el-button type="primary" @click="edit()">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'StockList',
}
</script>
<style scoped></style>