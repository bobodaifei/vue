<script setup>
import { reactive } from "vue";
import { useRouter } from 'vue-router';
import request from "@/utils/request";
import { ElMessage } from 'element-plus';
import { activeRouter } from "@/utils/permission";
import { useUserStore } from '@/stores/counter'
const store = useUserStore();
store.$reset();
localStorage.removeItem("token")
let form = reactive({})

//模拟权限
let permissions = [
  {
    menusId: "1001", title: "商品管理", icon: "Menu", childMenu: [
      { name: "StockList", path: "/StockList", title: "商品列表" },
      { name: "Index01", path: "/Index01", title: "库存管理" }
    ]
  },
  {
    menusId: "1002", title: "商品管理1", icon: "Menu", childMenu: [
      { name: "Index21", path: "/Index21", title: "商品列表" }
    ]
  },
]

const router = useRouter()
const login = () => {
  request.post("/javaweb05/user?method=login", form).then((res) => {
    if (res.code == "0") {
      ElMessage({
        message: '登录成功',
        type: 'success',
      })
      let _user = res.data
      _user.permissions = permissions
      store.user = _user
      activeRouter()
      localStorage.setItem('token', res.data.token);
      router.push('/Home')
    } else {
      ElMessage.error(res.msg)
    }
  });
}

</script>
<template>
  <div>
    <el-form :model="form" label-width="120px">
      <el-form-item label="账号">
        <el-input v-model="form.user_no" />
      </el-form-item>
      <el-form-item label="密码">
        <el-input v-model="form.password" />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="login">登录</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: 'Login',
}
</script>
<style scoped></style>