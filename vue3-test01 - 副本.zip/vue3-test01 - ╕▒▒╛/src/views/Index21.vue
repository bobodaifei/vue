<template>
  <div>
    Index21
  </div>
</template>
<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Index01"
}
</script>

<style scoped></style>