<script setup>
import { useUserStore } from '@/stores/counter'
const store = useUserStore();

console.log();
</script >

<template>
  <div>
    {{ store.user }} 
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "404"
}
</script>

<style scoped></style>