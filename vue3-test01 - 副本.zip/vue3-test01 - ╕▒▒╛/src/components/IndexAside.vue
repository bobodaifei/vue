<script setup>
import { useUserStore } from '@/stores/counter'
import { useRouter } from 'vue-router'
// import { defineEmits } from 'vue'

const store = useUserStore();
let permissions = store.user.permissions

const router = useRouter()

const emit = defineEmits(["addTab"]);
const addTab = (path, title, name) => {
  emit('addTab', path, title, name)
}
</script>

<template>
  <div>
    <!-- default-active 在element-plus 解释有问题 -->
    <el-menu :default-active="router.currentRoute.value.path" class="el-menu-vertical-demo" style="width: 200px; min-height: calc(100vh - 50px)"
      router>
      <el-menu-item index="/Home">首页</el-menu-item>
      <template v-for="menus in permissions">
        <!-- eslint-disable-next-line vue/valid-v-for -->
        <el-sub-menu :index="menus.title">
          <template #title>
            <el-icon>
              <component :is="menus.icon"></component>
            </el-icon>
            <span>{{ menus.title }}</span>
          </template>
          <!-- eslint-disable-next-line vue/valid-v-for -->
          <el-menu-item v-for="menu in menus.childMenu" :index="menu.path" 
            @click="addTab(menu.path, menu.title, menu.name)">{{ menu.title }}</el-menu-item>
        </el-sub-menu>
      </template>
    </el-menu>

  </div>
</template>


<script>
export default {
  name: "IndexAside",
}
</script>

<style scoped></style>
