import { defineAsyncComponent } from "vue"
import IndexLayout from '@/layout/IndexLayout.vue'
import { useUserStore } from '@/stores/counter'
import pinia from '@/stores/store'
import router from '@/router'
import { h } from 'vue'

// 注意：这个文件是设置动态路由的
// permissions是一个资源的数组



export function activeRouter() {
  const store = useUserStore(pinia);
  let permissions = store.user.permissions

  if (permissions && permissions.length > 0) {
    let root = {
      path: '/Index',
      name: 'IndexLayout',
      component: IndexLayout,
      redirect: "/Home",
      children: [
        {
          path: '/Home',
          name: 'Home',
          component: () => import("@/views/Home.vue")
        },
      ]
    }
    permissions.forEach((menus) => {
      menus.childMenu.forEach((menu) => {

        // const modules = import.meta.glob('@/views/*.vue')
        let child = {
          path: menu.path,
          name: menu.name,
          meta: {
            title: menu.title
          },
          // component: () => import(`/src/views${menu.path}.vue`)
          component: {
            render: () => h(defineAsyncComponent(() => import(/* @vite-ignore */`../views/${menu.name}.vue`)))
          }

          // component: defineAsyncComponent(() => import(/* @vite-ignore */`@/views/StockList.vue`))
          // component: modules[`/src/views${menu.path}.vue`]
        };
        root.children.push(child)
      })

    })
    if (router) {
      //请注意，添加路由并不会触发新的导航。也就是说，除非触发新的导航，否则不会显示所添加的路由。
      router.addRoute(root)
    }
  }
}



